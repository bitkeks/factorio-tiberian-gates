data.raw.gate["gate"].open_sound.variations.filename = "__Tiberian Gates__/sound/gate-down.ogg"
data.raw.gate["gate"].close_sound.variations.filename = "__Tiberian Gates__/sound/gate-up.ogg"
