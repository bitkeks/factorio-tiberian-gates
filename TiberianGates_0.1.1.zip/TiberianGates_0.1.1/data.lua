data.raw.gate["gate"].open_sound.variations.filename = "__TiberianGates__/sound/gate-down.ogg"
data.raw.gate["gate"].close_sound.variations.filename = "__TiberianGates__/sound/gate-up.ogg"
