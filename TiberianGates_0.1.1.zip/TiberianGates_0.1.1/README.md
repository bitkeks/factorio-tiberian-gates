# Tiberian Gates

Nostalgia mod for Factorio 0.13 which replaces the default gate sounds with the original
sounds from Command & Conquer Tiberian Sun. 

This mod is licensed under the MIT license, https://mit-license.org/

Inspiration by Red Alerts mod, https://github.com/Suprcheese/Red-Alerts

Credits for the sound files go to Westwood Studios - the developers of the
original game - and EA, because they bought the studio and released the series as
freeware.
